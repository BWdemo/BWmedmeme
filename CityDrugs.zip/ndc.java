import java.io.*;
import java.util.*;

public class ndc

{
	public static void main(String[] args) throws IOException
	{
		String[] str = new String[100];
		String ndcinputfilename = "";
    	String countinputfilename = "";    	
    	String outputfilename = ""; 
		
		BufferedReader br = null;
		HashMap<String,String> map = new HashMap<String, String>(); 
		HashMap<String,String> mapcount = new HashMap<String, String>(); 
		String line=""; 
		String[] ndcsplit,countsplit=null;		
		String drug = null, ndc=null,count=null,origvalue=null;
		String temp="";	
		
		for(int i=0;i<args.length;i++)
	    {
			str[i]=args[i];			
		}   	
            
        for(int i=0;i<args.length;i++)
        {
        	if (str[i].compareTo("-i")==0)
        	{
        		ndcinputfilename=str[i+1];        		
        	}
        	if (str[i].compareTo("-i1")==0)
        	{	
        		countinputfilename=str[i+1];
        	}
        	if (str[i].compareTo("-o")==0)
        	{	
        		outputfilename=str[i+1];
        	}         	
        } 
		
		br = new BufferedReader(new FileReader(ndcinputfilename));
		
		FileWriter fw = null;        
        BufferedWriter bw = null;  
        
        fw=new FileWriter(outputfilename);      
        bw = new BufferedWriter(fw);
		
		while ((line = br.readLine()) != null) 
        {
        	ndcsplit = line.split("\\|",-1);        	
        	drug=ndcsplit[0];
        	ndc=ndcsplit[1];       	
        	
        	if(map.containsKey(drug))
    		{
        		origvalue=map.get(drug);        		
        		temp=origvalue+"|"+ndc;    			 			  			
    			map.remove(drug);    			
    			map.put(drug,temp);            	   			   			
    		}  
        	else
        	{        		
        		map.put(drug,ndc);
        	}      	
        }				
		br.close();
		String valuestring=null;
		
		br = new BufferedReader(new FileReader(countinputfilename));
		while ((line = br.readLine()) != null) 
        {
        	countsplit = line.split("\\|",-1);        
        	drug=countsplit[0];
        	count=countsplit[1];           	
        	
        	if(map.containsKey(drug))
    		{
        		origvalue=map.get(drug);        		
        		valuestring=count + "|"+origvalue;
        		mapcount.put(drug,valuestring);        		
        		bw.write(drug+"|"+valuestring+"\n");
    		} 	
        	else
        	{        		
        		mapcount.put(drug,count);
        		bw.write(drug+"|"+count+"\n");
        	}
        }	
		
		br.close();		
		bw.close();		
	}
}