import java.io.*;
import java.text.*;
import java.util.*;

public class csvtheranr 
{
	public static void main(String[] args) throws IOException, ParseException 
	{
		
		String[] str = new String[100];
		String inputfilename = "";
    	String therainputfilename = "";    	
    	String outputfilename = ""; 	
        
        StringBuffer buf=new StringBuffer();
        String newLine=buf.toString();
        String newLine1=buf.toString();
        String newLine2=buf.toString();
        String newLine3=buf.toString();
      
        FileWriter fw = null;        
        BufferedWriter bw= null;
        BufferedReader br = null, br1=null;
        String line, line1, line2,line3,line4,line5= "";        
        HashMap<String,String> map = new HashMap<String, String>();               
       
        String[] rep=new String[10];
        String user="";
        
        String value ="";        
        String[] data =new String[100];          
          
        SimpleDateFormat sdfIn = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat sdfOut = new SimpleDateFormat("yyyy-MM-dd");
       
        for(int i=0;i<args.length;i++)
	    {
			str[i]=args[i];			
		}   	
            
        for(int i=0;i<args.length;i++)
        {
        	if (str[i].compareTo("-d")==0)
        	{
        		inputfilename=str[i+1];        		
        	}
        	if (str[i].compareTo("-t")==0)
        	{	
        		therainputfilename=str[i+1];
        	}
        	if (str[i].compareTo("-o")==0)
        	{	
        		outputfilename=str[i+1];
        	}         	
        } 
        
        br = new BufferedReader(new FileReader(therainputfilename));
        br1 = new BufferedReader(new FileReader(inputfilename));        
        
        fw=new FileWriter(outputfilename);      
        bw = new BufferedWriter(fw);     
        
        while ((line = br.readLine()) != null) 
        {
        	String[] thera = line.split("\\|",-1);        	
        	map.put(thera[0].toLowerCase().trim(),thera[1]);        	
        }       
        
        while ((line1 = br1.readLine()) != null) 
        {       	
        	buf.append(line1);
        	data = line1.split("\\|",-1);  
        	String input = data[4];
        	Date date = sdfIn.parse(input);
        	String outdate = sdfOut.format(date);        	
            data[4]=outdate;            
        	line2 = data[0];
            line3=data[1]+"|"+data[2]+"|"+data[3]+"|";        	
        	line4 = data[4]+"|"+data[5]+"|";
        	line5 = data[6]; 
        	
        	if(data[0]!=null)
        	{
        		
        		rep=data[0].split("\\s+");
        		user=rep[0];
        		buf.append("|");
        		buf.append(user);
        	}
        	
        	else{
        		user=data[0];
        	}
        	
        	
        	newLine3=line2+"|"+user+"|"+line3;
        	
        	if(data[3].contains("0"))
        	{        		
        		newLine=newLine3+"New"+"|"+line4;        		
        		buf.append("|");
        		buf.append("New");
        	}
        	else
        	{        		
        		newLine=newLine3+"Refill"+"|"+line4;        		
        		buf.append("|");
        		buf.append("Refill");
        	}          	
        	
        	data[5]= data[5].toLowerCase().trim();
        	
        	if(map.get(data[5].toLowerCase().trim())!=null)
        	{   
        		value=map.get(data[5]);
        		newLine1=newLine+value;        		
        		buf.append("|");
        		buf.append(value); 	   	 		
        	}        	
        	else
        	{       		
        		value="Other";
        		newLine1=newLine+value;        		
        		buf.append("|");
            	buf.append("Other");            	
        	}
        	
        	newLine2=newLine1+"|"+line5;        	
        	bw.write(newLine2+"\n");    	         
        }          
        br.close();
        br1.close();
        bw.close();       
	}
}
