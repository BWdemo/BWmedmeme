import java.io.*;
import java.util.*;

public class thera_count_mpr
{
	public static void main(String[] args) throws IOException 
	{
		String[] str = new String[100];
		String inputfilename = "";    	   	
    	String outputfilename = ""; 	
    	
    	FileWriter fw = null;        
        BufferedWriter bw= null;
    	BufferedReader br = null;
	    String line,key=null;        
	    HashMap<String,String> drugmap = new HashMap<String, String>();  
	    String[] drug = null;
	    String[] arr= null;	     
	    int newvalue=0;
	    int MPR=0;
	    String tempval="";
	    int mrpval=0;
	    
	    for(int i=0;i<args.length;i++)
	    {
			str[i]=args[i];			
		}   	
            
        for(int i=0;i<args.length;i++)
        {
        	if (str[i].compareTo("-i")==0)
        	{
        		inputfilename=str[i+1];        		
        	}        	
        	if (str[i].compareTo("-o")==0)
        	{	
        		outputfilename=str[i+1];
        	}         	
        } 
	    
	    br = new BufferedReader(new FileReader(inputfilename));
	    fw=new FileWriter(outputfilename);      
        bw = new BufferedWriter(fw); 
        
	    line = br.readLine();
	    while ((line = br.readLine()) != null) 
	    {	    	
	    	drug = line.split("\\|",-1);       
	      	key=String.valueOf(drug[10]);
	      	MPR=Integer.valueOf(drug[11]).intValue();      	
	      	 
	      	if(drugmap.containsKey(key))
	      	{
	      		tempval=drugmap.get(key);
	      		// newvalue=drugmap.get(key);
	      		arr= tempval.split("\\|",-1);
	      		mrpval=Integer.valueOf(arr[1]).intValue()+MPR;
	      		newvalue=newvalue+1; 
	      		tempval=newvalue+"|"+ mrpval;
	      	}
	      	else
	      	{
	      		newvalue=1;
	      		mrpval=MPR;
	      		tempval=newvalue+"|"+ mrpval;
	      	}
	      	drugmap.remove(key);
	      	drugmap.put(key,tempval);
	    }
	    for (Map.Entry<String, String> e : drugmap.entrySet()) 
	    {    	   
	    	String k = e.getKey().toString();    	   
	        String v = e.getValue().toString();	    	   
	        //System.out.println("Key:"+k+"|"+"Value:"+v);	
	        bw.append(k+"|"+v+'\n');
	    } 
	    br.close();
	    bw.close();
	}
}