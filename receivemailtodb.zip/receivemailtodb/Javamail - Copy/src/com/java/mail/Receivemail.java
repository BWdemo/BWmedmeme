package com.java.mail;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.sql.*;
import java.io.*;
import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.AuthenticationFailedException;

import java.lang.RuntimeException;

import javax.mail.*;
import javax.naming.AuthenticationException;
public class Receivemail {

	public static void main(String args[]) throws MessagingException,AuthenticationException,ArrayIndexOutOfBoundsException,IOException, ClassNotFoundException{
		
		//input the mail account credential	
		InputStream inputStream = null;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String User;  
		System.out.println("Enter gmailid: ");
		User = br.readLine();
		BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
		String Password;  
		System.out.println("Enter Password: ");
		Password = br1.readLine();
		
		//connection for mysql */
		final String JDBCDRIVER = "com.mysql.jdbc.Driver";  
		final String DBURL = "jdbc:mysql://localhost:3306/mail";
		final String DBUser ="root";
		final String DBPassword="root";
		Connection conn = null;
		Statement stmt = null;  
		
		//create some properties and get the default Session
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.base64.ignoreerrors", "true");
		props.put("mail.imaps.partialfetch", "false");
		Session session = Session.getInstance(props,  new javax.mail.Authenticator() {
		protected PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(User, Password);
		}
	  });
		
		// Get a Store object and open a folder 
		Store store = session.getStore("imaps");
		store.connect("smtp.gmail.com",User,Password);
		Folder inbox=store.getFolder("INBOX");
		inbox.open(Folder.READ_WRITE);
		int messageCount=inbox.getMessageCount();
		Message[] m =inbox.getMessages();
		System.out.println("Email number" + m.length );
		int i=3;
		// create the Multipart and its parts to it	
		Message message = m[i];  
		Multipart multipart = (Multipart)m[i].getContent();
	    BodyPart bp = multipart.getBodyPart(0);
	    inputStream = m[i].getInputStream();
	 	System.out.println("The mpart is"+bp.getContent().toString());
	    System.out.println("The file size is"+multipart.getContentType());
	    System.out.println("The file part is"+multipart.getBodyPart(0));
	    String address =InternetAddress.toString(m[i].getFrom());
	    //Connection driver and connection establishment
	try {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(DBURL,DBUser,DBPassword);
	    System.out.println("connected sucessfully");
    	stmt = conn.createStatement();
		String sql;
		PreparedStatement st = conn.prepareStatement("insert into emaildatas (Subject,content,receivedfrom,body)values (?,?,?,?);");
		st.setString(1, m[i].getSubject());
		st.setBlob(2, inputStream);
		st.setString(3,address);
		st.setString(4, bp.getContent().toString());
		st.executeUpdate();
		stmt.close();
		conn.close();
		} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}

	
	}

}
