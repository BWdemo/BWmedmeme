import java.io.*;
import java.util.*;

public class prescriber_count
{
	public static void main(String[] args) throws IOException 
	{
		String[] str = new String[100];
		String inputfilename = "";    	   	
    	String outputfilename = ""; 
    	
    	FileWriter fw = null;        
        BufferedWriter bw= null;
		BufferedReader br = null;
	    String line,key=null;        
	    HashMap<String,Integer> drugmap = new HashMap<String, Integer>();  
	    String[] drug = null;
	    Integer newvalue=0;	  
	    
	    for(int i=0;i<args.length;i++)
	    {
			str[i]=args[i];			
		}   	
            
        for(int i=0;i<args.length;i++)
        {
        	if (str[i].compareTo("-i")==0)
        	{
        		inputfilename=str[i+1];        		
        	}        	
        	if (str[i].compareTo("-o")==0)
        	{	
        		outputfilename=str[i+1];
        	}         
        }
	     
	    br = new BufferedReader(new FileReader(inputfilename));
	    fw=new FileWriter(outputfilename);      
        bw = new BufferedWriter(fw);
        
	    line = br.readLine();
	    while ((line = br.readLine()) != null) 
	    {	    	
	    	drug = line.split("\\|",-1);       
	      	key=drug[2];	      	
	      	if(drugmap.containsKey(key))
	      	{
	      		newvalue=drugmap.get(key);
	      		newvalue=newvalue+1; 
	      	}
	      	else
	      	{
	      		newvalue=1;
	        }
	        drugmap.remove(key);
	        drugmap.put(key,newvalue);
	    }
	    for (Map.Entry<String, Integer> e : drugmap.entrySet()) 
	    {    	   
	    	String k = e.getKey().toString();    	   
	        String v = e.getValue().toString();	    	   
	        //System.out.println("Key:"+k+"|"+"Value:"+v);
	        bw.append(k+"|"+v+'\n');
	    } 
	    br.close();
	    bw.close();
	}
}