import java.io.*;
import java.util.*;

public class csvthera 
{
	public static void main(String[] args) throws IOException 
	{
		String[] str = new String[100];
		String inputfilename = "";
    	String therainputfilename = "";    	
    	String outputfilename = "";
    	String outputfilename1 = "";
        
        StringBuffer buf=new StringBuffer();
        String newLine=buf.toString();
        String newLine1=buf.toString();
        String newLine2=buf.toString();
        String newLine3=buf.toString();
        String newLine4=buf.toString();
        String newLine5=buf.toString();
      
        FileWriter fw,fw1 =null;        
        BufferedWriter bw,bw1 = null;
        BufferedReader br = null, br1=null;
        String line, line1, line2,line3= "";        
        HashMap<String,String> map = new HashMap<String, String>();               
       
        String value ="";
        String[] data =new String[100];        
        String[] rep=new String[10];
        String user="";
        String sym = "$";
       
        for(int i=0;i<args.length;i++)
	    {
			str[i]=args[i];			
		}   	
            
        for(int i=0;i<args.length;i++)
        {
        	if (str[i].compareTo("-d")==0)
        	{
        		inputfilename=str[i+1];        		
        	}
        	if (str[i].compareTo("-t")==0)
        	{	
        		therainputfilename=str[i+1];
        	}
        	if (str[i].compareTo("-o")==0)
        	{	
        		outputfilename=str[i+1];
        	} 
        	if (str[i].compareTo("-o1")==0)
        	{	
        		outputfilename1=str[i+1];
        	} 
        } 
        
        br = new BufferedReader(new FileReader(therainputfilename));
        br1 = new BufferedReader(new FileReader(inputfilename)); 
        br1.readLine(); 
        
        fw=new FileWriter(outputfilename);      
        bw = new BufferedWriter(fw); 
        
        fw1=new FileWriter(outputfilename1);      
        bw1 = new BufferedWriter(fw1); 
        
        while ((line = br.readLine()) != null) 
        {
        	String[] thera = line.split("\\|",-1);        	
        	map.put(thera[0], thera[1]);          
        }
                     
        while ((line1 = br1.readLine()) != null) 
        {       	
        	buf.append(line1);
        	data = line1.split("\\|",-1); 
        	line2 = data[0]+"|"+data[1]+"|"+data[2]+"|"+data[3]+"|"+data[4]+"|"+data[5]+"|"+data[6]+"|";
        	line3= data[7]+"|"+data[8]+"|"+data[9]+"|"+data[10]+"|"+data[11]+"|"+data[12];
        	
        	if ((data[7]!=null) && (data[8]!=null) && (data[9]!=null) && (data[10]!=null) && (data[11]!=null) && (data[12]!=null))
        	{        		
        		data[7]  = sym+data[7];
        		data[8]  = sym+data[8];
        		data[9]  = sym+data[9];
        		data[10] = sym+data[10];
        		data[11] = sym+data[11];
        		data[12] = sym+data[12];        		
        	}
        	else
        	{
        		data[7]  = sym+"0";
        		data[8]  = sym+"0";
        		data[9]  = sym+"0";
        		data[10] = sym+"0";
        		data[11] = sym+"0";
        		data[12] = sym+"0";  
        	}
        	
        	newLine3 = line2+data[7]+"|"+data[8]+"|"+data[9]+"|"+data[10]+"|"+data[11]+"|"+data[12];   	
        	
        	if(map.get(data[5])!=null)
        	{
        		value=map.get(data[5]);
        		buf.append("|");
        		buf.append(value); 	   	 		
        	}        	
        	else
        	{
        		value="Others";
        		buf.append("|");
            	buf.append("Others");            	
        	}
        	
        	newLine=line2+"|"+line3+"|"+value;
        	newLine4=newLine3+"|"+value;
        	
        	if(data[3].contains("0"))
        	{
        		newLine1=newLine+"|"+"New";
        		newLine5=newLine4+"|"+"New";
        		buf.append("|");
        		buf.append("New");
        	}
        	else
        	{
        		newLine1=newLine+"|"+"Refill";
        		newLine5=newLine4+"|"+"Refill";
        		buf.append("|");
        		buf.append("Refill");
        	}       
        	
        	bw1.write(newLine5+"\n");        	
        		
        	if(data[0]!=null)
        	{
        		rep=data[0].split("\\s+");
        		user=rep[0];
        		newLine2=newLine1+"|"+user;
        		buf.append("|");
        		buf.append(user);
        	}  
        	
        	bw.write(newLine2+"\n");         	
        }          
        br.close();
        br1.close();
        bw.close();
        bw1.close();
	}
}
